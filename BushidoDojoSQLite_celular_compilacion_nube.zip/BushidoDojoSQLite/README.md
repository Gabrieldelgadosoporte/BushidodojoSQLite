# Bushido Dojo Manager — proyecto Android con SQLite

Este paquete contiene el **código fuente** de un MVP nativo Android. No es un APK ya compilado.

## Funciones incluidas
- Base de datos SQLite local (no usa nube).
- Tabla de alumnos y tabla de pagos.
- 18 alumnos iniciales: LEO, ALEJANDRA, DIEGO, MELI, ANGELIN, CHAMPI, OSSURU, VIC, KING JULIAN, BRIAN, EMI, KIKE, FER, SAULIN, MARIJO, JULY, LALITO y CHRISS.
- Registro/edición de alumno: nombre, edad, grado, escuela (Bushido León / Flow), disciplinas (Judo Kodokan, Jiu-Jitsu, MMA), mensualidad individual y notas.
- Registro de pagos completos o parciales, mes, fecha, método, notas y folio consecutivo.
- Historial de pagos e informe sencillo de ingresos del mes.
- Exportación de respaldo JSON mediante el selector de archivos Android.

## Compilar
1. En una computadora, instala Android Studio.
2. Abre la carpeta `BushidoDojoSQLite` (no solo el ZIP) en Android Studio.
3. Deja que Gradle sincronice el proyecto. Requiere conexión para descargar herramientas de compilación.
4. Conecta el teléfono con depuración USB o usa un emulador.
5. Pulsa Run para instalar la app de prueba.
6. Para crear un APK: Build > Build Bundle(s) / APK(s) > Build APK(s).

## Importante
- Este proyecto fuente no ha sido compilado ni probado en un dispositivo físico en este entorno.
- La base de datos se guarda dentro del espacio privado de la app. Al desinstalarla o borrar sus datos, Android puede eliminarla. Usa la opción de respaldo con frecuencia.
- La importación/restauración de respaldos, recibos PDF imprimibles, edición/eliminación auditada de pagos, cálculo automático de adeudos por mes y reportes avanzados son mejoras pendientes para la siguiente versión.


## Compilar usando solamente el celular (GitHub Actions)
Se agregó un flujo de compilación en `.github/workflows/build-apk.yml`.

1. En Chrome del celular, entra a https://github.com y crea una cuenta o inicia sesión.
2. Crea un repositorio nuevo llamado `BushidoDojoSQLite` (puede ser privado).
3. Sube el contenido de esta carpeta/ZIP al repositorio, conservando la estructura de carpetas. En GitHub web, puedes usar **Add file > Upload files**; descomprime el ZIP primero en el teléfono con la app Archivos.
4. Abre la pestaña **Actions** del repositorio y habilita Actions si GitHub lo solicita.
5. En el flujo **Build Bushido Dojo APK**, pulsa **Run workflow**.
6. Cuando termine con marca verde, abre la ejecución y descarga el artefacto `BushidoDojoManager-debug-apk`. Dentro está `app-debug.apk`.
7. Descarga el APK al teléfono y ábrelo para instalarlo. Android puede pedir que permitas instalar aplicaciones desde Chrome o Archivos; permite solo si estás seguro de que el APK viene de tu propio repositorio.

El flujo usa GitHub Actions para compilar en la nube. La base de datos de la aplicación sigue siendo local en el teléfono; el código fuente subido a GitHub sí queda en la cuenta elegida. No guardes datos reales de alumnos en el repositorio.
